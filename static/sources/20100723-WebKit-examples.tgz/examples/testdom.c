/* Copyright © 2009 Xan Lopez <xan@gnome.org> */

/* Modified for GUADEC-ES 2010: 22nd - 23th July
   Copyright © 2009 Mario Sanchez Prada <msanchez@igalia.com> */

/* Build with:
   gcc -o testdom testdom.c $(pkg-config --cflags --libs webkit-1.0) -Wall -O1 -g */

#include <webkit/webkit.h>

#define PAGE "<html><body><h1><a href=\"http://www.google.com\">Google</a></h1><h2><a href=\"http://www.webkit.org\">WebKit</a></h2></body></html>"

static void phase_one(GtkButton *button, WebKitWebView *view);
static gboolean phase_two(WebKitDOMCSSStyleDeclaration *style);
static gboolean phase_three(WebKitDOMCSSStyleDeclaration *style);
static gboolean phase_four(WebKitDOMCSSStyleDeclaration *style);

static void
phase_one(GtkButton *button, WebKitWebView *view)
{
  WebKitDOMDocument* document = webkit_web_view_get_dom_document(view);
  WebKitDOMHTMLCollection *collection = webkit_dom_document_get_links(document);
  gulong length = webkit_dom_html_collection_get_length(collection);
  guint i;

  for (i = 0; i < length; i++) {
    WebKitDOMNode *node = webkit_dom_html_collection_item(collection, i);
    WebKitDOMElement* element = (WebKitDOMElement*)node;
    WebKitDOMCSSStyleDeclaration *style = webkit_dom_element_get_style(element);
    webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-property", "top, color", "", NULL);
    webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-duration", "3s, 3s", "", NULL);
    webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-timing-function", "ease-in, ease-in", "", NULL);
    webkit_dom_css_style_declaration_set_property(style, "top", "300px", "", NULL);
    webkit_dom_css_style_declaration_set_property(style, "color", "red", "", NULL);
    webkit_dom_css_style_declaration_set_property(style, "position", "relative", "", NULL);
    g_timeout_add(3000, (GSourceFunc)phase_two, style);
  }
}

static gboolean
phase_two(WebKitDOMCSSStyleDeclaration *style)
{
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-property", "left, color", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-duration", "3s, 3s", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-timing-function", "ease-in, ease-in", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "left", "500px", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "color", "yellow", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "position", "relative", "", NULL);
  g_timeout_add(3000, (GSourceFunc)phase_three, style);
  return FALSE;
}

static gboolean
phase_three(WebKitDOMCSSStyleDeclaration *style)
{
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-property", "top, color", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-duration", "3s, 3s", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-timing-function", "ease-in, ease-in", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "top", "0px", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "color", "green", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "position", "relative", "", NULL);
  g_timeout_add(3000, (GSourceFunc)phase_four, style);
  return FALSE;
}

static gboolean
phase_four(WebKitDOMCSSStyleDeclaration *style)
{
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-property", "left, color", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-duration", "3s, 3s", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "-webkit-transition-timing-function", "ease-in, ease-in", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "left", "0px", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "color", "blue", "", NULL);
  webkit_dom_css_style_declaration_set_property(style, "position", "relative", "", NULL);

  return FALSE;
}

int main(int argc, char** argv)
{
  GtkWidget *window, *box, *button, *scrolled, *view;

  gtk_init(&argc, &argv);

  g_thread_init (NULL);
  gtk_init (&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_default_size(GTK_WINDOW(window), 640, 480);
  box = gtk_vbox_new(FALSE, 5);
  gtk_container_add(GTK_CONTAINER(window), box);

  scrolled = gtk_scrolled_window_new(NULL, NULL);
  view = webkit_web_view_new();
  gtk_container_add(GTK_CONTAINER(scrolled), view);
  gtk_box_pack_start(GTK_BOX(box), scrolled, TRUE, TRUE, 0);

  button = gtk_button_new_with_label("Dance links!");
  g_signal_connect(button, "clicked", G_CALLBACK(phase_one), view);
  gtk_box_pack_start(GTK_BOX(box), button, FALSE, FALSE, 0);

  if (argc == 1)
    webkit_web_view_load_string(WEBKIT_WEB_VIEW(view), PAGE, NULL, NULL, NULL);
  else
    webkit_web_view_load_uri(WEBKIT_WEB_VIEW(view), argv[1]);

  gtk_widget_show_all(window);

  gtk_main();

  return 0;
}
