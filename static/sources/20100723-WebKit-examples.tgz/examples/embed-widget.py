#!/usr/bin/env python
# -*- coding: utf-8 -*-

import gtk
import os
import webkit

def entry_activated_cb(entry, embed):
    embed.open(entry.get_text())


def button_clicked_cb(button, embed):
    script = "document.body.style.backgroundColor = \"#000000\";"
    embed.execute_script (script)

    script = "document.body.style.color = \"#ffffff\";"
    embed.execute_script (script)

    embed.execute_script ("alert(woot)")


def embed_create_plugin_widget_cb(embed, mime_type, uri, param):
    if mime_type == "application/x-gtk-widget":
        widget = gtk.Button(stock=gtk.STOCK_APPLY)
        widget.connect("clicked", button_clicked_cb, embed)
        widget.show_all()
        return widget

    return None

# Widgets and signals
window = gtk.Window()
window.set_default_size(1024, 768)
window.set_title("Mini browser")
entry = gtk.Entry()
entry.connect('activate', entry_activated_cb, embed)

embed = webkit.WebView(); # WebKit embed
embed.load_uri("file://" + os.path.dirname(os.path.abspath(__file__)) + "/index.html");
embed.connect('create-plugin-widget', embed_create_plugin_widget_cb)

# Pack everything up and show
vbox = gtk.VBox(False, 5)
vbox.pack_start(entry, False, False)
vbox.pack_start(embed)
window.add(vbox)
window.show_all()

gtk.main()
