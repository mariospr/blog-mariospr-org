/* vim: set sw=2 ts=2 sts=2 noet: */

/* For GUADEC2009 WebKitGTK+ presentation: July 2009
   Copyright © 2009 Christian Dywan <christian@twotoasts.de> */

/* Modified for EncuentroLinux 2009: 22nd - 24th October
   Copyright © 2009 Diego Escalante Urrelo <diegoe@gnome.org> */

/* Modified for GUADEC-ES 2010: 22nd - 23th July
   Copyright © 2009 Mario Sanchez Prada <msanchez@igalia.com> */

/* This code is licensed under the terms of the expat license */

/* Build with:
   gcc -o embed-widget embed-widget.c $(pkg-config --cflags --libs webkit-1.0) -Wall -O1 -g */


#include <webkit/webkit.h>

#define FILE_URI \
  "file:///home/mario/work/Igalia/talks/20100723-WebKit/examples/index.html"

static gboolean
window_delete_event_cb (GtkWidget  *widget,
                        GdkEvent   *event,
                        gpointer    user_data)
{
  gtk_main_quit ();
  return FALSE;
}

static void
plugin_clicked_cb (GtkButton     *button,
                       WebKitWebView *web_view)
{
  char *script;

  script = "document.body.style.backgroundColor = \"#000000\";";
  webkit_web_view_execute_script (web_view, script);

  script = "document.body.style.color = \"#ffffff\";";
  webkit_web_view_execute_script (web_view, script);

  webkit_web_view_execute_script (web_view, "alert(woot)");
}

static GtkWidget*
web_view_create_plugin_widget_cb (GtkWidget*   web_view,
                                  const gchar* mime_type,
                                  const gchar* uri,
                                  GHashTable*  param,
                                  gpointer     userdata)
{
  if (g_str_equal (mime_type, "application/x-gtk-widget"))
    {
      GtkWidget *widget;

      widget = gtk_button_new_with_label ("Click me!");
      g_signal_connect (widget, "clicked",
                        G_CALLBACK (plugin_clicked_cb), web_view);

      gtk_widget_show (widget);

      return widget;
    }

  return NULL;
}

int
main (int    argc,
      gchar *argv[])
{
  gtk_init (&argc, &argv);
  if (!g_thread_supported ())
    g_thread_init (NULL);

  GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_default_size (GTK_WINDOW (window), 800, 600);
  gtk_widget_set_name (window, "GtkLauncher");

  GtkWidget* scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
  gtk_container_add (GTK_CONTAINER (window), scrolled_window);

  WebKitWebView *web_view = WEBKIT_WEB_VIEW (webkit_web_view_new ());
  gtk_container_add (GTK_CONTAINER (scrolled_window), GTK_WIDGET (web_view));

  g_signal_connect (G_OBJECT (web_view), "create-plugin-widget",
                    G_CALLBACK (web_view_create_plugin_widget_cb), NULL);

  g_signal_connect (G_OBJECT (window), "delete-event",
                    G_CALLBACK (window_delete_event_cb), NULL);


  webkit_web_view_load_uri(web_view, FILE_URI);

  gtk_widget_grab_focus (GTK_WIDGET (web_view));
  gtk_widget_show_all (window);
  gtk_main ();

  return 0;
}
