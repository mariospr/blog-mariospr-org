#!/usr/bin/env python
# -*- coding: utf-8 -*-

import gtk
import webkit

def entry_activated_cb(entry, embed):
    embed.open(entry.get_text())

# Widgets and signals
window = gtk.Window()
window.set_default_size(1024, 768)
window.set_title("Mini browser")
embed = webkit.WebView(); # WebKit embed
entry = gtk.Entry()
entry.connect('activate', entry_activated_cb, embed)

# Pack everything up and show
vbox = gtk.VBox(False, 5)
vbox.pack_start(entry, False, False)
vbox.pack_start(embed)
window.add(vbox)
window.show_all()

gtk.main()
