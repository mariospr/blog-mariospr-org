/*
 * maemo-sb-plugin.h -- Example of a status bar plugin for Maemo
 *
 * This file is published under the GNU GPLv3.
 * See COPYING for the full license text.
 *
 * Copyright (C) 2008 Mario Sanchez Prada <msanchez@igalia.com>
 */

#include <gtk/gtk.h>
#include <libosso.h>
#include <libhildondesktop/statusbar-item.h>
#include <libhildondesktop/libhildondesktop.h>

#include "maemo-sb-plugin.h"

#define APP_VERSION "0.1"

#define MAIN_PANEL_X_OFFSET 0
#define MAIN_PANEL_Y_OFFSET 10
#define MAIN_PANEL_WIDTH 300

#define EXAMPLE_ITEM_STRING "Click me!"
#define HIDE_ITEM_STRING "Hide status bar plugin"

#define MAEMO_SB_PLUGIN_GET_PRIVATE(object)      \
        (G_TYPE_INSTANCE_GET_PRIVATE ((object), \
                                      MAEMO_SB_PLUGIN_TYPE, MaemoSbPluginPrivate))

typedef struct _MaemoSbPluginPrivate MaemoSbPluginPrivate;
struct _MaemoSbPluginPrivate
{
  osso_context_t *osso_context;

  gboolean is_visible;

  GtkWidget *button;
  GtkWidget *icon;
  GtkWidget *main_panel;
  GtkWidget *example_item;
  GtkWidget *hide_item;

  gint plugin_btn_handler_id;
  gint main_panel_handler_id;
  gint example_item_handler_id;
  gint hide_item_handler_id;

  gboolean dispose_has_run;
};

HD_DEFINE_PLUGIN (MaemoSbPlugin, maemo_sb_plugin, STATUSBAR_TYPE_ITEM);


/* Initialization/destruction functions */
static void maemo_sb_plugin_class_init (MaemoSbPluginClass *klass);
static void maemo_sb_plugin_init (MaemoSbPlugin *msbp);
static void maemo_sb_plugin_dispose (GObject *object);

/* Setters */
static void set_visibility (MaemoSbPlugin *msbp, gboolean visible);

/* Panel update functions */
static void main_panel_create (MaemoSbPlugin *msbp);

/* Signals handlers */
static void plugin_btn_toggled (GtkWidget *button, gpointer data);
static void main_panel_item_activated (GtkWidget *item, gpointer data);
static void main_panel_hidden (GtkWidget *main_panel, gpointer user_data);
static void main_panel_position_func (GtkMenu   *main_panel,
                                      gint      *x,
                                      gint      *y,
                                      gboolean  *push_in,
                                      gpointer   data);

/* Initialization/destruction functions */

static void
maemo_sb_plugin_class_init (MaemoSbPluginClass *klass)
{
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  /* Important: redefine dispose, not finalize */
  object_class->dispose = maemo_sb_plugin_dispose;

  g_type_class_add_private (object_class,
                            sizeof (MaemoSbPluginPrivate));
}

static void
maemo_sb_plugin_init (MaemoSbPlugin *msbp)
{
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);

  /* Init private attributes to their default values */
  priv->osso_context = NULL;
  priv->is_visible = TRUE;
  priv->button = NULL;
  priv->icon = NULL;
  priv->main_panel = NULL;
  priv->example_item = NULL;
  priv->hide_item = NULL;
  priv->dispose_has_run = FALSE;

  /* Setup libosso */
  priv->osso_context = osso_initialize ("maemo_sb_plugin",
                                        APP_VERSION, TRUE, NULL);
  if (!priv->osso_context) {
    g_debug ("Unable to initialize OSSO context");
    return;
  }

  /* Create status bar plugin button */
  priv->button = gtk_toggle_button_new ();
  priv->icon = gtk_image_new_from_stock (GTK_STOCK_CONVERT,
                                         GTK_ICON_SIZE_LARGE_TOOLBAR);

  gtk_button_set_image (GTK_BUTTON (priv->button),
                        priv->icon);

  gtk_container_add (GTK_CONTAINER (msbp), priv->button);

  /* Connect signals */
  priv->plugin_btn_handler_id =
    g_signal_connect (priv->button, "toggled",
                      G_CALLBACK(plugin_btn_toggled), msbp);

  /* Show widgets */
  gtk_widget_show_all (priv->button);

  /* Create main panel */
  main_panel_create (msbp);

  /* Update visibililty */
  set_visibility (msbp, priv->is_visible);
}

static void
maemo_sb_plugin_dispose (GObject *object)
{
  MaemoSbPlugin *msbp = MAEMO_SB_PLUGIN (object);
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);

  /* Ensure dispose is called only once */
  if (priv->dispose_has_run) {
    return;
  }
  priv->dispose_has_run = TRUE;

  /* Libosso cleanup */
  osso_deinitialize (priv->osso_context);

  /* Disconnect signal handlers */
  g_signal_handler_disconnect (priv->button,
                               priv->plugin_btn_handler_id);
  g_signal_handler_disconnect (priv->main_panel,
                               priv->main_panel_handler_id);
  g_signal_handler_disconnect (priv->example_item,
                               priv->example_item_handler_id);
  g_signal_handler_disconnect (priv->hide_item,
                               priv->hide_item_handler_id);

  /* Destroy local widgets */
  if (priv->main_panel) {
    gtk_widget_destroy (priv->main_panel);
  }

  G_OBJECT_CLASS (g_type_class_peek_parent
                  (G_OBJECT_GET_CLASS(object)))->dispose(object);
}

/* Setters */

static void
set_visibility (MaemoSbPlugin *msbp, gboolean visible)
{
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);
  gboolean old_condition;
  g_object_get (msbp, "condition", &old_condition, NULL);
  if (old_condition != visible) {
    g_object_set (msbp, "condition", visible, NULL);
  }

  priv->is_visible = visible;
}

/* Panel update functions */

static void
main_panel_create (MaemoSbPlugin *msbp)
{
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);
  GtkWidget *label;

  /* Create main_panel and main_panel items */
  priv->main_panel = gtk_menu_new ();
  gtk_widget_set_size_request (priv->main_panel, MAIN_PANEL_WIDTH, -1);

  priv->example_item = gtk_menu_item_new_with_label (EXAMPLE_ITEM_STRING);
  priv->hide_item = gtk_menu_item_new_with_label (HIDE_ITEM_STRING);

  /* Add items to main_panel */
  gtk_menu_append (priv->main_panel, priv->example_item);
  gtk_menu_append (priv->main_panel, priv->hide_item);

  /* Connect signals */
  priv->main_panel_handler_id =
    g_signal_connect(priv->main_panel,
                     "selection-done",
                     G_CALLBACK(main_panel_hidden), msbp);
  priv->example_item_handler_id =
    g_signal_connect(priv->example_item, "activate",
                     G_CALLBACK (main_panel_item_activated), msbp);
  priv->hide_item_handler_id =
    g_signal_connect(priv->hide_item, "activate",
                     G_CALLBACK (main_panel_item_activated), msbp);

  /* Show widgets */
  gtk_widget_show_all (priv->main_panel);
}

/* Signals handlers */

static void
plugin_btn_toggled (GtkWidget *button, gpointer data)
{
  MaemoSbPlugin *msbp = MAEMO_SB_PLUGIN (data);
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);

  if (!gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON (button)))
    return;

  gtk_menu_popup (GTK_MENU (priv->main_panel),
                  NULL, NULL,
                  main_panel_position_func, msbp,
                  1,
                  gtk_get_current_event_time ());
}

static void
main_panel_item_activated (GtkWidget *item, gpointer data)
{
  MaemoSbPlugin *msbp = MAEMO_SB_PLUGIN (data);
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);
  const gboolean interactive = TRUE;

  if (item == priv->example_item) {
    hildon_banner_show_information (NULL, NULL, "Item clicked!");
    g_debug ("Item clicked");
  } else if (item == priv->hide_item) {
    set_visibility (msbp, FALSE);
    hildon_banner_show_information (NULL, NULL, "Status bar plugin hidden");
    g_debug ("Status bar plugin hidden");
  } else {
    g_debug ("Unknown action");
  }
}

static void
main_panel_hidden (GtkWidget *main_panel, gpointer data)
{
  MaemoSbPlugin *msbp = MAEMO_SB_PLUGIN (data);
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (msbp);

  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(priv->button), FALSE);
}

static void
main_panel_position_func (GtkMenu   *main_panel,
                          gint      *x,
                          gint      *y,
                          gboolean  *push_in,
                          gpointer   data)
{
  MaemoSbPluginPrivate *priv = MAEMO_SB_PLUGIN_GET_PRIVATE (data);

  GtkRequisition req;

  gtk_widget_size_request (GTK_WIDGET (main_panel->toplevel), &req);

  gdk_window_get_origin (GDK_WINDOW (GTK_WIDGET (priv->button)->window), x, y);
  *x += (priv->button->allocation.x + priv->button->allocation.width
         - req.width + MAIN_PANEL_X_OFFSET);
  *y += (priv->button->allocation.y + priv->button->allocation.height
         + MAIN_PANEL_Y_OFFSET);
}
