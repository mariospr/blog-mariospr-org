/*
 * maemo-sb-plugin.h -- Example of a status bar plugin for Maemo
 *
 * This file is published under the GNU GPLv3.
 * See COPYING for the full license text.
 *
 * Copyright (C) 2008 Mario Sanchez Prada <msanchez@igalia.com>
 */

#ifndef MAEMO_SB_PLUGIN_H
#define MAEMO_SB_PLUGIN_H

#include <glib.h>
#include <glib-object.h>
#include <libhildondesktop/statusbar-item.h>

G_BEGIN_DECLS

#define MAEMO_SB_PLUGIN_TYPE            (maemo_sb_plugin_get_type ())
#define MAEMO_SB_PLUGIN(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MAEMO_SB_PLUGIN_TYPE, MaemoSbPlugin))
#define MAEMO_SB_PLUGIN_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MAEMO_SB_PLUGIN_TYPE, MaemoSbPluginClass))
#define MAEMO_IS_SB_PLUGIN(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MAEMO_SB_PLUGIN_TYPE))
#define MAEMO_IS_SB_PLUGIN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MAEMO_SB_PLUGIN_TYPE))
#define MAEMO_SB_PLUGIN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MAEMO_SB_PLUGIN_TYPE, MaemoSbPluginClass))

typedef struct _MaemoSbPlugin      MaemoSbPlugin;
typedef struct _MaemoSbPluginClass MaemoSbPluginClass;

struct _MaemoSbPlugin
{
  StatusbarItem parent;
};

struct _MaemoSbPluginClass
{
  StatusbarItemClass parent_class;
};

GType maemo_sb_plugin_get_type(void);

G_END_DECLS

#endif /* !MAEMO_SB_PLUGIN_H */
